﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btngen = New System.Windows.Forms.Button()
        Me.btnstore = New System.Windows.Forms.Button()
        Me.txtlogin = New System.Windows.Forms.TextBox()
        Me.txtpass = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lstrtv = New System.Windows.Forms.ListBox()
        Me.btnrtv = New System.Windows.Forms.Button()
        Me.txtgen = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtacct = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btngen
        '
        Me.btngen.Location = New System.Drawing.Point(13, 21)
        Me.btngen.Name = "btngen"
        Me.btngen.Size = New System.Drawing.Size(145, 23)
        Me.btngen.TabIndex = 0
        Me.btngen.Text = "Generate Strong Password"
        Me.btngen.UseVisualStyleBackColor = True
        '
        'btnstore
        '
        Me.btnstore.Location = New System.Drawing.Point(13, 50)
        Me.btnstore.Name = "btnstore"
        Me.btnstore.Size = New System.Drawing.Size(145, 23)
        Me.btnstore.TabIndex = 0
        Me.btnstore.Text = "Store Password:"
        Me.btnstore.UseVisualStyleBackColor = True
        '
        'txtlogin
        '
        Me.txtlogin.Location = New System.Drawing.Point(368, 52)
        Me.txtlogin.Name = "txtlogin"
        Me.txtlogin.Size = New System.Drawing.Size(100, 20)
        Me.txtlogin.TabIndex = 2
        '
        'txtpass
        '
        Me.txtpass.Location = New System.Drawing.Point(536, 52)
        Me.txtpass.Name = "txtpass"
        Me.txtpass.Size = New System.Drawing.Size(132, 20)
        Me.txtpass.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(326, 55)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(36, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Login:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(474, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Password:"
        '
        'lstrtv
        '
        Me.lstrtv.FormattingEnabled = True
        Me.lstrtv.Location = New System.Drawing.Point(12, 112)
        Me.lstrtv.Name = "lstrtv"
        Me.lstrtv.Size = New System.Drawing.Size(776, 329)
        Me.lstrtv.TabIndex = 4
        '
        'btnrtv
        '
        Me.btnrtv.Location = New System.Drawing.Point(13, 83)
        Me.btnrtv.Name = "btnrtv"
        Me.btnrtv.Size = New System.Drawing.Size(201, 23)
        Me.btnrtv.TabIndex = 5
        Me.btnrtv.Text = "Retrieve / Refresh Passwords"
        Me.btnrtv.UseVisualStyleBackColor = True
        '
        'txtgen
        '
        Me.txtgen.Location = New System.Drawing.Point(167, 23)
        Me.txtgen.Name = "txtgen"
        Me.txtgen.Size = New System.Drawing.Size(364, 20)
        Me.txtgen.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(164, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Account:"
        '
        'txtacct
        '
        Me.txtacct.Location = New System.Drawing.Point(220, 52)
        Me.txtacct.Name = "txtacct"
        Me.txtacct.Size = New System.Drawing.Size(100, 20)
        Me.txtacct.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 459)
        Me.Controls.Add(Me.txtacct)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnrtv)
        Me.Controls.Add(Me.lstrtv)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtgen)
        Me.Controls.Add(Me.txtpass)
        Me.Controls.Add(Me.txtlogin)
        Me.Controls.Add(Me.btnstore)
        Me.Controls.Add(Me.btngen)
        Me.Name = "Form1"
        Me.Text = "UltraPass V0.8 (©2020 Andrew Offer)"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btngen As Button
    Friend WithEvents btnstore As Button
    Friend WithEvents txtlogin As TextBox
    Friend WithEvents txtpass As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lstrtv As ListBox
    Friend WithEvents btnrtv As Button
    Friend WithEvents txtgen As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtacct As TextBox
End Class
