﻿Imports System.IO
Public Class Form1
    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles txtpass.TextChanged, txtgen.TextChanged
    End Sub
    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtlogin.TextChanged
    End Sub
    Dim ultrapassword As String = InputBox("Enter your encryption key. (Each password uses this to de/encrypt, if you lose this or enter the key incorrectly, your stored passwords will not decrypt properly.)")
    Dim encryptword As String = ""
    Dim decryptword As String = ""
    Dim encryptfactor As Decimal = encryptfact()


    Function encryptfact()
        Dim encryptfactoree As Decimal = 0
        Dim x As Decimal = 0
        For Each letter As String In ultrapassword
            encryptfactoree = encryptfactoree + Asc(letter)
            x = x + 1
        Next
        Return ((encryptfactoree / x))
    End Function

    Sub Read()
        Dim reader As New StreamReader("Passwords.csv") 'Opens the passwords file to read from'
        'declares login variables'
        Dim Login As String
        Dim Password As String
        Dim Site As String
        Dim varc As Array
        'resets the listbox to default values'
        lstrtv.Items.Clear()
        lstrtv.Items.Add("ACCOUNT : LOGIN : PASSWORD")
        lstrtv.Items.Add("")
        'sends login details to listbox to be displayed'
        While reader.EndOfStream = False
            varc = reader.ReadLine.Split(",")
            Site = varc(0)
            Login = varc(1)
            Password = varc(2)
            lstrtv.Items.Add((decrypt(Site) & ":  " & decrypt(Login) & ":  " & decrypt(Password))) ' Displays all decrypted information
        End While
        'closes the file, allowing another operation to use it'
        reader.Close()
    End Sub
    Function decrypt(word)

        decryptword = ""
        For Each letter As String In word
            decryptword += Chr(Asc(letter) - encryptfactor)
        Next
        Return (decryptword)
    End Function
    Function encrypt(word)

        encryptword = ""
        For Each letter As String In word
            encryptword += Chr(Asc(letter) + encryptfactor)
        Next
        Return (encryptword)
    End Function
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnstore.Click


        'declares login details'
        Dim login As String = txtlogin.Text
        Dim pass As String = txtpass.Text
        Dim site As String = txtacct.Text
        Dim write As New StreamWriter("Passwords.csv", True)
        write.WriteLine(encrypt(site) & "," & encrypt(login) & "," & encrypt(pass))
        write.Close()
        MessageBox.Show("Login details added to file")
        Read()
    End Sub
    Private Sub btngen_Click(sender As Object, e As EventArgs) Handles btngen.Click
        MessageBox.Show(encryptfactor)
        txtgen.Clear()   'clears any text previously stored in the listbox
        Dim N1 As Integer
        Dim randomS As New Random 'is used to create a random number
        Dim alphabet As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!£$%^&*" 'defines the alphabet
        Dim S1 As String = "" ' clears the variable that stores the password
        Dim Symbol As String = "!£$%^&*" ' defines the important aspects of the password
        Dim search As Integer
        'Generates first random password
        For x = 0 To 13
            N1 = randomS.Next(0, 68)
            S1 = S1 + alphabet.Substring(N1, 1)
        Next
        search = S1.IndexOf(Symbol) 'checks if the first password includes important characters
        'If the first password does not include important characters, this will create a new password
        If search = -1 Then
            S1 = ""
            For x = 0 To 13
                N1 = randomS.Next(0, 68)
                S1 = S1 + alphabet.Substring(N1, 1)
            Next
        End If
        txtgen.Text += (S1) 'outputs the generated password to the listbox
    End Sub
    Private Sub btnrtv_Click(sender As Object, e As EventArgs) Handles btnrtv.Click
        Read()
    End Sub
End Class
